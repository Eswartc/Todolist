package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText editTextTask;
    private Button buttonAdd;
    private ListView listViewTasks;
    private ArrayList<String> tasks;
    private ArrayAdapter<String> tasksAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        editTextTask = findViewById(R.id.editTextTask);
        buttonAdd = findViewById(R.id.buttonAdd);
        listViewTasks = findViewById(R.id.listViewTasks);

        // Initialize tasks list
        tasks = new ArrayList<>();

        // Initialize adapter
        tasksAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tasks);

        // Set the adapter to the ListView
        listViewTasks.setAdapter(tasksAdapter);

        // Set click listener for the Add button
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask();
            }
        });

        // Set click listener for the ListView items
        listViewTasks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                removeTask(position);
            }
        });
    }

    private void addTask() {
        String task = editTextTask.getText().toString().trim();
        if(task.length() == 0){
            editTextTask.setHint("Task cannot be empty!");
        }else{
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yy  HH:mm:ss");
            Calendar cal = Calendar.getInstance();
            task+="\n"+dateFormat.format(cal.getTime()).toString();
            if (!task.isEmpty()) {
                tasks.add(task);
                tasksAdapter.notifyDataSetChanged();
                editTextTask.setText("");
            }editTextTask.setHint("Enter a task");
        }
    }

    private void removeTask(int position) {
        tasks.remove(position);
        tasksAdapter.notifyDataSetChanged();
    }
}
